"""
5. Ingresar el nombre de tu carrera dentro de los valores que tienes en tu diccionario.
-
Mostrar en consola los valores de tu carrera y nombre agregándolos a una variable c/u
"""
departamentos={'A':'Lima','B':'Piura','C':'Arequipa','D':'Cajamarca','E':'La Libertad','F':'Junin'}
print(departamentos)
departamentos['Profesión']="Ingeniero Metalúrgico"
print(departamentos)