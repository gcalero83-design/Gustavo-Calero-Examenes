'''
1. Crea correctamente un diccionario con los campos de: nombre, edad, salario y edad.
Convierte tu diccionario finalmente a una lista y muestra el resultado en la terminal.
'''
diccionario = {'Nombre': 'Gustavo','Edad': 42,'salario': 4500,'edad': 42}
print(diccionario)
lista=list(diccionario.values())
print(lista)
